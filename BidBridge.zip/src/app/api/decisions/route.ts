import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAuth, logAudit } from "@/lib/auth";
import { DecisionType, Role, BidStatus } from "@prisma/client";
import { dataStore } from "@/lib/dataStore";

const schema = z.object({
  bidId: z.string().min(1),
  decision: z.nativeEnum(DecisionType),
  reason: z.string().min(3),
});

export async function POST(req: NextRequest) {
  try {
    const user = await requireAuth([Role.OFFICER, Role.ADMIN]);
    const body = await req.json();
    const data = schema.parse(body);

    // Try Prisma first if DB is online
    try {
      const bid = await prisma.bid.findFirst({
        where: {
          OR: [
            { id: data.bidId },
            { id: { startsWith: data.bidId } },
          ],
        },
        include: { bidder: true },
      });

      if (bid) {
        let officerUser = await prisma.user.findFirst({ where: { role: Role.OFFICER } });
        const officerId = officerUser?.id || user.id;

        const decision = await prisma.officerDecision.upsert({
          where: { bidId: bid.id },
          create: {
            bidId: bid.id,
            officerId,
            decision: data.decision,
            reason: data.reason,
          },
          update: {
            officerId,
            decision: data.decision,
            reason: data.reason,
          },
        });

        let newStatus: BidStatus = bid.status;
        if (data.decision === DecisionType.QUALIFY) newStatus = BidStatus.TECHNICALLY_QUALIFIED;
        if (data.decision === DecisionType.DISQUALIFY) newStatus = BidStatus.TECHNICALLY_DISQUALIFIED;
        if (data.decision === DecisionType.REQUEST_CLARIFICATION) newStatus = BidStatus.UNDER_EVALUATION;

        await prisma.bid.update({
          where: { id: bid.id },
          data: { status: newStatus },
        });

        await logAudit(officerId, "OFFICER_DECISION", "Bid", bid.id, {
          decision: data.decision,
          reason: data.reason,
        });

        try {
          await prisma.notification.create({
            data: {
              userId: bid.bidderId,
              title: `Decision: ${data.decision}`,
              message: data.reason,
              link: "/bidder/my-bids",
            },
          });
        } catch {}

        // Also record in dataStore
        dataStore.recordDecision({
          bidId: data.bidId,
          officerId,
          decision: data.decision,
          reason: data.reason,
        });

        return NextResponse.json(decision, { status: 201 });
      }
    } catch (e) {
      console.error("Prisma decision error, falling back to dataStore:", e);
    }

    // Save with dataStore
    const decision = dataStore.recordDecision({
      bidId: data.bidId,
      officerId: user.id,
      decision: data.decision,
      reason: data.reason,
    });

    if (!decision) {
      return NextResponse.json({ error: "Bid not found" }, { status: 404 });
    }

    return NextResponse.json(decision, { status: 201 });
  } catch (e: any) {
    if (e.name === "ZodError") return NextResponse.json({ error: "Validation failed", details: e.errors }, { status: 400 });
    console.error("Decision failed:", e);
    return NextResponse.json({ error: "Decision failed" }, { status: 500 });
  }
}

export async function GET() {
  try {
    await requireAuth([Role.OFFICER, Role.ADMIN]);

    try {
      const decisions = await prisma.officerDecision.findMany({
        include: {
          bid: { include: { tender: true, bidder: { include: { bidderProfile: true } } } },
          officer: { select: { name: true, email: true } },
        },
        orderBy: { createdAt: "desc" },
      });
      if (decisions && decisions.length > 0) {
        return NextResponse.json(decisions);
      }
    } catch {}

    const storeDecisions = dataStore.getDecisions();
    return NextResponse.json(storeDecisions);
  } catch (e: any) {
    console.error(e);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
