import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, logAudit } from "@/lib/auth";
import { BidStatus, Role } from "@prisma/client";
import { dataStore } from "@/lib/dataStore";
import { z } from "zod";

export async function GET(_: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;

  try {
    const bid = await prisma.bid.findUnique({
      where: { id },
      include: {
        tender: { include: { requirements: true } },
        bidder: { select: { id: true, name: true, email: true, bidderProfile: true } },
        documents: true,
        compliance: { include: { requirement: true } },
        evidence: true,
        recommendation: true,
        decision: true,
        riskResult: true,
      },
    });
    if (bid) return NextResponse.json(bid);
  } catch {}

  const storeBid = dataStore.getBidById(id);
  if (!storeBid) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json(storeBid);
}

const updateSchema = z.object({
  status: z.string().optional(),
});

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireAuth();
    const { id } = await params;
    const body = await req.json();
    const data = updateSchema.parse(body);

    try {
      const bid = await prisma.bid.findUnique({ where: { id } });
      if (bid) {
        const updated = await prisma.bid.update({
          where: { id },
          data: {
            status: data.status as BidStatus,
            submittedAt: data.status === "SUBMITTED" ? new Date() : undefined,
          },
        });
        await logAudit(user.id, data.status === "SUBMITTED" ? "BID_SUBMIT" : "BID_UPDATE", "Bid", id, data);
        return NextResponse.json(updated);
      }
    } catch {}

    const storeBid = dataStore.getBidById(id);
    if (!storeBid) return NextResponse.json({ error: "Not found" }, { status: 404 });

    if (data.status) {
      storeBid.status = data.status as any;
      if (data.status === "SUBMITTED") {
        storeBid.submittedAt = new Date().toISOString();
      }
      storeBid.updatedAt = new Date().toISOString();
    }

    await logAudit(user.id, "BID_UPDATE", "Bid", id, data);
    return NextResponse.json(storeBid);
  } catch (e: any) {
    console.error(e);
    return NextResponse.json({ error: "Update failed" }, { status: 500 });
  }
}
