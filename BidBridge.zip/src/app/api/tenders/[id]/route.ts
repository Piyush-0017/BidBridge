import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, logAudit } from "@/lib/auth";
import { Role, TenderStatus } from "@prisma/client";
import { dataStore } from "@/lib/dataStore";
import { z } from "zod";

export async function GET(_: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  try {
    const tender = await prisma.tender.findUnique({
      where: { id },
      include: {
        requirements: true,
        documents: true,
        corrigenda: true,
        bids: {
          include: {
            bidder: { select: { id: true, name: true, email: true, bidderProfile: true } },
            recommendation: true,
            decision: true,
            riskResult: true,
          },
        },
      },
    });
    if (tender) return NextResponse.json(tender);
  } catch {}

  const storeTender = dataStore.getTenderById(id);
  if (!storeTender) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json(storeTender);
}

const updateSchema = z.object({
  title: z.string().optional(),
  description: z.string().optional(),
  status: z.nativeEnum(TenderStatus).optional(),
  bidEndAt: z.string().optional(),
  estimatedValue: z.number().optional(),
});

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireAuth([Role.OFFICER, Role.ADMIN]);
    const { id } = await params;
    const body = await req.json();
    const data = updateSchema.parse(body);

    try {
      const tender = await prisma.tender.update({
        where: { id },
        data: {
          ...data,
          bidEndAt: data.bidEndAt ? new Date(data.bidEndAt) : undefined,
        },
      });
      await logAudit(user.id, "TENDER_UPDATE", "Tender", id, data);
      return NextResponse.json(tender);
    } catch {}

    const storeTender = dataStore.getTenderById(id);
    if (!storeTender) return NextResponse.json({ error: "Not found" }, { status: 404 });

    Object.assign(storeTender, data);
    await logAudit(user.id, "TENDER_UPDATE", "Tender", id, data);
    return NextResponse.json(storeTender);
  } catch (e: any) {
    console.error(e);
    return NextResponse.json({ error: "Update failed" }, { status: 500 });
  }
}
