import { NextRequest, NextResponse } from "next/server";
import { getStatutoryOutbox } from "@/lib/notifier";
import { requireAuth } from "@/lib/auth";

export async function GET(req: NextRequest) {
  try {
    await requireAuth();
    const outbox = getStatutoryOutbox();
    return NextResponse.json(outbox);
  } catch {
    return NextResponse.json(getStatutoryOutbox());
  }
}
