import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { dataStore } from "@/lib/dataStore";

export async function GET() {
  try {
    const user = await requireAuth();

    try {
      const notifications = await prisma.notification.findMany({
        where: { userId: user.id },
        orderBy: { createdAt: "desc" },
        take: 50,
      });
      if (notifications && notifications.length > 0) {
        return NextResponse.json(notifications);
      }
    } catch {}

    const storeNotifications = dataStore.getNotifications(user.id);
    return NextResponse.json(storeNotifications);
  } catch (e: any) {
    console.error(e);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const user = await requireAuth();
    const body = await req.json();
    const { id, all } = body;

    try {
      if (all) {
        await prisma.notification.updateMany({
          where: { userId: user.id, read: false },
          data: { read: true },
        });
      } else if (id) {
        await prisma.notification.updateMany({
          where: { id, userId: user.id },
          data: { read: true },
        });
      }
    } catch {}

    const list = dataStore.getNotifications(user.id);
    list.forEach((n) => {
      if (all || n.id === id) n.read = true;
    });

    return NextResponse.json({ ok: true });
  } catch (e: any) {
    console.error(e);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
