import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { Role } from "@prisma/client";
import { dataStore } from "@/lib/dataStore";

export async function GET() {
  try {
    await requireAuth([Role.OFFICER, Role.ADMIN]);

    let resultLogs: any[] = [];
    try {
      const logs = await prisma.auditLog.findMany({
        orderBy: { createdAt: "desc" },
        take: 200,
        include: { actor: { select: { id: true, name: true, email: true } } },
      });
      if (logs && logs.length > 0) {
        resultLogs = logs;
      }
    } catch {}

    if (resultLogs.length === 0) {
      resultLogs = dataStore.getAuditLogs();
    }

    const { verifyAuditChainIntegrity } = await import("@/lib/auditChain");
    const chainVerification = verifyAuditChainIntegrity(resultLogs);

    return NextResponse.json({
      logs: resultLogs,
      chainVerification,
    });
  } catch (e: any) {
    console.error(e);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
