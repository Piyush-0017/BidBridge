import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "BidBridge — AI-Powered Tender & Bid Management",
  description: "End-to-end government tender discovery, bidding, compliance and evaluation platform",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
