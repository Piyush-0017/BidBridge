"use client";

import { useEffect, useState } from "react";
import { Shell } from "@/components/Shell";

export default function OfficerNotifications() {
  const [items, setItems] = useState<any[]>([]);

  function load() {
    fetch("/api/notifications").then((r) => r.json()).then(setItems);
  }
  useEffect(() => { load(); }, []);

  async function markAll() {
    await fetch("/api/notifications", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ all: true }),
    });
    load();
  }

  return (
    <Shell role="officer" title="Notifications">
      <div className="mb-4 flex justify-end">
        <button onClick={markAll} className="btn btn-outline px-3 py-1 text-sm">Mark all read</button>
      </div>
      <div className="card divide-y">
        {items.length === 0 && <p className="p-6 text-slate-500">No notifications.</p>}
        {items.map((n) => (
          <div key={n.id} className={`p-4 ${n.read ? "" : "bg-blue-50"}`}>
            <div className="font-medium">{n.title}</div>
            <p className="text-sm text-slate-600 mt-1">{n.message}</p>
            <div className="text-xs text-slate-400 mt-1">{new Date(n.createdAt).toLocaleString()}</div>
          </div>
        ))}
      </div>
    </Shell>
  );
}
