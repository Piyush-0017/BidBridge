import type { GovernmentAdapter, CheckRequest, CheckResult, GovernmentVerificationRecord } from "./types";

export class MockAdapter implements GovernmentAdapter {
  sourceType = "GSTN" as const;
  name = "Mock/Sandbox Government Verification Adapter";

  async check(r: CheckRequest): Promise<CheckResult> {
    const successCodes = ["GST_VALID", "PAN_VALID", "UDYAM", "TECH_SPEC"];
    const status = successCodes.includes(r.requirementCode) || Math.random() > 0.3 ? "VERIFIED" : "PENDING";

    return {
      status,
      source: "MOCK_" + r.requirementCode,
      reference: "DEMO-" + Date.now().toString(36).toUpperCase(),
      evidence: `Simulated verification for ${r.companyName}. Transparency: DEMO VERIFIED — SIMULATED SOURCE.`,
      checkedAt: new Date().toISOString(),
    };
  }

  async verify(r: CheckRequest): Promise<GovernmentVerificationRecord> {
    return {
      source: "GSTN",
      mode: "SIMULATED_SOURCE",
      status: "VERIFIED",
      transparencyLabel: "DEMO VERIFIED — SIMULATED SOURCE",
      referenceNumber: "DEMO-" + Date.now().toString(36).toUpperCase(),
      verifiedAt: new Date().toISOString(),
      extractedFields: { companyName: r.companyName },
      evidenceSummary: `Simulated verification for ${r.companyName}. Transparency: DEMO VERIFIED — SIMULATED SOURCE.`,
      confidence: 0.95,
    };
  }
}

export function getAdapter(): MockAdapter {
  return new MockAdapter();
}
