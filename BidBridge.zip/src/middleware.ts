import { NextRequest, NextResponse } from "next/server";
import { jwtVerify } from "jose";

const JWT_SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET || "CHANGE_TO_LONG_RANDOM_SECRET_IN_PRODUCTION_32CHARS+"
);
const COOKIE_NAME = "sih_session";

async function getSessionUser(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return null;

  try {
    const { payload } = await jwtVerify(token, JWT_SECRET);
    return payload as { id: string; email: string; role: string; name: string };
  } catch {
    return null;
  }
}

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // Static assets and internal next bundles pass through
  if (
    pathname.startsWith("/_next") ||
    pathname.startsWith("/favicon") ||
    pathname.startsWith("/api") ||
    pathname === "/manpower-worker.png" ||
    pathname === "/" ||
    pathname === "/signup" ||
    pathname === "/bidder-guide" ||
    pathname.startsWith("/bidder-guide/")
  ) {
    return NextResponse.next();
  }

  const session = await getSessionUser(req);

  // If visiting /login while already logged in, redirect directly to user's assigned panel
  if (pathname === "/login") {
    if (session) {
      if (session.role === "OFFICER" || session.role === "ADMIN") {
        return NextResponse.redirect(new URL("/officer", req.url));
      }
      return NextResponse.redirect(new URL("/bidder", req.url));
    }
    return NextResponse.next();
  }

  // Officer route protection: only OFFICER or ADMIN allowed
  if (pathname === "/officer" || pathname.startsWith("/officer/")) {
    if (!session) {
      const loginUrl = new URL("/login", req.url);
      return NextResponse.redirect(loginUrl);
    }
    if (session.role === "BIDDER") {
      // Bidders can ONLY see the bidder panel
      return NextResponse.redirect(new URL("/bidder", req.url));
    }
    return NextResponse.next();
  }

  // Bidder route protection: only BIDDER allowed
  if (pathname === "/bidder" || pathname.startsWith("/bidder/")) {
    if (!session) {
      const loginUrl = new URL("/login", req.url);
      return NextResponse.redirect(loginUrl);
    }
    if (session.role === "OFFICER" || session.role === "ADMIN") {
      // Officers can ONLY see the officer/tender panel
      return NextResponse.redirect(new URL("/officer", req.url));
    }
    return NextResponse.next();
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
